package tanksshellmanager;

import TanksCommon.Model.TanksResourceManagerModel;


public class ShellManagerModel extends TanksResourceManagerModel
{
    
}
