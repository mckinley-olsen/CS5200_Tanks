/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TanksCommon;

import java.util.Scanner;

/**
 *
 * @author Mik
 */
public class Tanks {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        /*
        Listener l = new Listener();
        l.start();
        
        Scanner input=new Scanner(System.in);
        int i=0;
        System.out.println("Enter -1 to quit");
        while(i!=-1)
        {
            i=input.nextInt();
        }
        */
        
    }
}
