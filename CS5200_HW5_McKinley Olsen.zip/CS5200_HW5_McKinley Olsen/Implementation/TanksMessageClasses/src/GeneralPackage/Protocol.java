package GeneralPackage;


public enum Protocol
{
    
}
