package tanksgunpowdermanager;

import TanksCommon.Model.TanksResourceManagerModel;

public class TanksGunpowderManagerModel extends TanksResourceManagerModel
{
    
}
