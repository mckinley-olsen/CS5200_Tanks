package TanksCommon.Model;

public class TanksModel 
{
    public static TanksModel instance = new TanksModel();
    
    protected TanksModel()
    {
        
    }
}
